﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace IBMK3Recon
{
    public class Class1
    {
        public static void CalculateTaxableGSTVariance(String SourcePath, String DestinationPath, String SheetName, String ColumnHeaderNameToBeFiltered)
        {
            Excel.Application ExlApp = new Excel.Application();
            ExlApp.DisplayAlerts = false;
            Excel.Workbook ExlWb = ExlApp.Workbooks.Open(SourcePath);
            Excel.Worksheet ExlWs = ExlWb.Worksheets[SheetName];
            int RowCount = ExlWs.UsedRange.Rows.Count;
            int ColumnCount = ExlWs.UsedRange.Columns.Count;
            int ColumnNumber = 1;
            ColumnCount = ExlWs.UsedRange.Columns.Count;
            for (int a = 1; a <= ColumnCount; a++)
            {
                if (String.Compare(ExlWs.Cells[1, a].Value.ToString().ToLower(), ColumnHeaderNameToBeFiltered.ToLower()) == 0)
                {
                    ColumnNumber = a;
                    break;
                }
            }
            List<int> RN = new List<int>();
            ExlWs.UsedRange.AutoFilter(ColumnNumber, Criteria1: "=*,*");
            Excel.Range visibleCells = ExlWs.UsedRange.SpecialCells(Excel.XlCellType.xlCellTypeVisible, Type.Missing);
            bool skip = true;
            foreach (Excel.Range area in visibleCells.Areas)
            {
                foreach (Excel.Range row in area.Rows)
                {
                    if (skip == false)
                    {
                        RN.Add(row.Row);
                    }
                    skip = false;
                }
            }
            ExlWs.AutoFilter.ShowAllData();
            ExlWs.Cells[2, 25].Formula = "=J2-INDIRECT(\"'K3'!M\"&SUBSTITUTE(X2,\"Available in Travel Agent Data in row(s) \",\"\"))";
            ExlWs.Range["Y2"].AutoFill(ExlWs.Range["Y2", "Y" + RowCount], Excel.XlAutoFillType.xlFillSeries);
            ExlWs.Cells[2, 26].Formula = "=U2-INDIRECT(\"'K3'!P\" & SUBSTITUTE(X2, \"Available in Travel Agent Data in row(s) \", \"\"))";
            ExlWs.Range["Z2"].AutoFill(ExlWs.Range["Z2", "Z" + RowCount], Excel.XlAutoFillType.xlFillSeries);
            for (int j = RN.Count() - 1; j >= 0; j--)
            {
                String s = ExlWs.Cells[RN.ElementAt(j), 24].Value;
                s = s.Replace("Available in Travel Agent Data in row(s) ", "");
                String MyFormula = String.Empty;
                String MyFormula2 = String.Empty;
                String[] MyArr = s.Split(',');
                foreach (String Value in MyArr)
                {
                    if (MyFormula == String.Empty)
                    {
                        MyFormula = "'K3'!M" + Convert.ToInt32(Value.Trim());
                        MyFormula2 = "'K3'!P" + Convert.ToInt32(Value.Trim());
                    }
                    else
                    {
                        MyFormula = MyFormula + "," + "'K3'!M" + Convert.ToInt32(Value.Trim());
                        MyFormula2 = MyFormula2 + "," + "'K3'!P" + Convert.ToInt32(Value.Trim());
                    }
                }
                ExlWs.Cells[RN.ElementAt(j), 25].Formula = "=J" + RN.ElementAt(j) + "-SUM(" + MyFormula + ")";
                ExlWs.Cells[RN.ElementAt(j), 26].Formula = "=U" + RN.ElementAt(j) + "-SUM(" + MyFormula2 + ")";
            }
            Console.WriteLine("Completed");
            ExlWb.SaveAs(DestinationPath, Excel.XlFileFormat.xlWorkbookDefault, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            ExlWb.Close();
            ExlApp.Quit();
        }
    }
}