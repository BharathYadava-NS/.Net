﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace HIL_Excel_Formatting
{
    public class ExcelManipulation
    {
        public Excel.Application ExlApp;
        public Excel.Workbook ExlWb;
        public Excel.Worksheet ExlWs;
        public Excel.Worksheet ExlWs2;
        public Excel.Range ExlRng;
        public StreamWriter s;
        private void RemoveBlankRowsColumns(String SourcePath, String DestinationPath, String FirstColumnHeader = "Header", int FirstRowNumber = 1)
        {
            try
            {
                ExlApp = new Excel.Application();
                ExlApp.DisplayAlerts = false;
                ExlWb = ExlApp.Workbooks.Open(SourcePath);
                ExlWs = ExlWb.Worksheets[1];
                int RowCount = ExlWs.UsedRange.Rows.Count + 1;
                int ColumnCount = ExlWs.UsedRange.Columns.Count;
                int i = 0;
                for (i = RowCount; i > 0; i--)
                {
                    if (ExlApp.WorksheetFunction.CountA(ExlWs.Rows[i]) <= 3)
                    {
                        ExlWs.Cells[i, 1].EntireRow.Delete();
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "Code") == 0 && i > FirstRowNumber)
                    {
                        ExlWs.Cells[i, 2].EntireRow.Delete();
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "Src Iden") == 0 && i > FirstRowNumber)
                    {
                        ExlWs.Cells[i, 2].EntireRow.Delete();
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "Account") == 0 && i > FirstRowNumber)
                    {
                        ExlWs.Cells[i, 2].EntireRow.Delete();
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "Account") == 0 && i < FirstRowNumber)
                    {
                        //ExlWs.Cells[i, 2].EntireRow.Delete();
                        ExlWs.Cells[i, 3] = ExlWs.Cells[i, 2].Value.ToString().Trim();
                        ExlWs.Cells[i, 2] = String.Empty;
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "Document Number") == 0 && i > FirstRowNumber)
                    {
                        ExlWs.Cells[i, 2].EntireRow.Delete();
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), FirstColumnHeader) == 0 && i > FirstRowNumber)
                    {
                        ExlWs.Cells[i, 2].EntireRow.Delete();
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "*") == 0)
                    {
                        ExlWs.Cells[i, 2].EntireRow.Delete();
                    }
                }
                ExlWs.Cells[RowCount, 1].EntireRow.Delete();
                for (i = ColumnCount; i > 0; i--)
                {
                    if (ExlWs.Cells[1, i].Value == null)
                    {
                        ExlWs.Cells[1, i].EntireColumn.Delete();
                    }
                    else
                    {
                        ExlWs.Cells[1, i] = ExlWs.Cells[1, i].Value.ToString().Trim();
                    }
                }
                //ExlApp.ActiveWorkbook.Save();
                ExlWb.SaveAs(DestinationPath, Excel.XlFileFormat.xlAddIn, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                //ExlWb.SaveAs(DestinationPath);
                ExlWb.Close();
                ExlApp.Quit();
            }
            catch (Exception e)
            {
            }
        }
        private void LogToFile(String FilePath,String logType,String Message)
        {
            if (logType.Equals("Audit"))
            {
                s = new StreamWriter(FilePath + @"\AuditLog.csv");
                s.WriteLine(DateTime.Now + ",HIL Excel Formatting Metabot," + Message);
            }
            else
            {
                s = new StreamWriter(FilePath + @"\ErrorLog.csv");
                s.WriteLine(DateTime.Now + ",HIL Excel Formatting Metabot," + Message);
            }
        }
        public void FormatSAPReport(String SourcePath,String DestinationPath,String SheetName,String ColumnHeaderNameToBeFiltered,int FirstHeaderRowNumber, String LogFilePath)
        {
            try
            {
                ExlApp = new Excel.Application();
                ExlApp.DisplayAlerts = false;
                ExlWb = ExlApp.Workbooks.Open(SourcePath);
                ExlWs = ExlWb.Worksheets[SheetName];
                for (int i = FirstHeaderRowNumber; i > 0; i--)
                {
                    if (ExlApp.WorksheetFunction.CountA(ExlWs.Rows[i]) <= 3)
                    {
                        ExlWs.Cells[i, 1].EntireRow.Delete();
                        LogToFile(LogFilePath, "Audit", "Deleting rows where =COLUMNA() function returns less than 2");
                    }
                    else if (String.Compare(ExlWs.Cells[i, 2].Text.ToString().Trim(), "Account") == 0 && i < FirstHeaderRowNumber)
                    {
                        ExlWs.Cells[i, 3] = ExlWs.Cells[i, 2].Value.ToString().Trim();
                        ExlWs.Cells[i, 2] = String.Empty;
                        LogToFile(LogFilePath, "Audit", "Swapping column for clumnn name \"account\" to avoid column mismatch changes");
                    }
                }
                int RowCount = ExlWs.UsedRange.Rows.Count + 1;
                int ColumnCount = ExlWs.UsedRange.Columns.Count;
                ExlWs.Cells[RowCount, 1].EntireRow.Delete();
                for (int i = ColumnCount; i > 0; i--)
                {
                    if (ExlWs.Cells[1, i].Value == null)
                    {
                        ExlWs.Cells[1, i].EntireColumn.Delete();
                        LogToFile(LogFilePath, "Audit", "Remove empty column in excel sheet while formatting");
                    }
                    else
                    {
                        ExlWs.Cells[1, i] = ExlWs.Cells[1, i].Value.ToString().Trim();
                        LogToFile(LogFilePath, "Audit", "Remove blanks present in column header if any");
                    }
                }
                LogToFile(LogFilePath, "Audit", "Remove empty columns in excel sheet while formatting");
                int ColumnNumber = 1;
                ColumnCount = ExlWs.UsedRange.Columns.Count;
                for (int a = 1; a <= ColumnCount; a++)
                {
                    if (String.Compare(ExlWs.Cells[1, a].Value.ToString().ToLower(), ColumnHeaderNameToBeFiltered.ToLower()) == 0)
                    {
                        ColumnNumber = a;
                        break;
                    }
                }
                LogToFile(LogFilePath, "Audit", "Filtering and removing blanks based on column number " + ColumnNumber);
                List<int> RN = new List<int>();
                ExlWs.UsedRange.AutoFilter(ColumnNumber, Criteria1: "=",Excel.XlAutoFilterOperator.xlOr,Criteria2:"="+ColumnHeaderNameToBeFiltered);
                Excel.Range visibleCells = ExlWs.UsedRange.SpecialCells(Excel.XlCellType.xlCellTypeVisible, Type.Missing);
                bool skip = true;
                foreach (Excel.Range area in visibleCells.Areas)
                {
                    foreach (Excel.Range row in area.Rows)
                    {
                        if (skip == false)
                        {
                            RN.Add(row.Row);
                        }
                        skip = false;
                    }
                }
                LogToFile(LogFilePath, "Audit", "Started Deleting rows based on column number " + ColumnNumber);
                ExlWs.AutoFilter.ShowAllData();
                for (int j = RN.Count() - 1; j >= 0; j--)
                {
                    ExlWs.Cells[RN.ElementAt(j), 1].EntireRow.Delete();
                }
                ExlWb.SaveAs(DestinationPath, Excel.XlFileFormat.xlAddIn, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                ExlWb.Close();
                ExlApp.Quit();
                LogToFile(LogFilePath, "Audit", "Saving all the changes to excel file and closing the same");
            }
            catch(Exception e)
            {
                LogToFile(LogFilePath, "Error", e.Message);
            }
        }

        public void AddNewColumns(String FilePath,String RangeValue,String ColumnName, String LogFilePath)
        {
            try
            {
                LogToFile(LogFilePath, "Audit", "Openeing excel file to add new columns");
                ExlApp = new Excel.Application();
                ExlApp.DisplayAlerts = false;
                ExlWb = ExlApp.Workbooks.Open(FilePath);
                ExlWs = ExlWb.Worksheets[1];
                String[] ColumnNames = ColumnName.Split(',');
                foreach(String Name in ColumnNames)
                {
                    ExlWs.Range[RangeValue].Insert(Excel.XlInsertShiftDirection.xlShiftToRight, Excel.XlInsertFormatOrigin.xlFormatFromRightOrBelow);
                    ExlWs.Range[RangeValue.Split(':')[1].ToString()+"1"].Value2 = Name;
                    LogToFile(LogFilePath, "Audit", "Added new column " + Name);
                }
                ExlWb.SaveAs(FilePath, Excel.XlFileFormat.xlAddIn, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                ExlWb.Close();
                ExlApp.Quit();
                LogToFile(LogFilePath, "Audit", "Saved the changes to excel file");
            }
            catch (Exception e)
            {
                LogToFile(LogFilePath, "Error", e.Message);
            }
        }
        public void AddNewSheetCopyHeaders(String FilePath,String SheetName, String LogFilePath)
        {
            try
            {
                ExlApp = new Excel.Application();
                ExlApp.DisplayAlerts = false;
                ExlWb = ExlApp.Workbooks.Open(FilePath);
                ExlWs = ExlWb.Worksheets[1];
                ExlWs2 = ExlWb.Worksheets.Add(After: ExlWs);
                ExlWs2.Name = SheetName;
                ExlWs.Range["A1"].EntireRow.Copy(ExlWs2.Range["A1"]);
                int ColumnCount = ExlWs2.UsedRange.Columns.Count;
                for (int i = ColumnCount; i > 0; i--)
                {
                    ExlWs2.Cells[1, i] = ExlWs2.Cells[1, i].Value.ToString().Replace('.',' ').Trim();
                }
                ExlWb.SaveAs(FilePath, Excel.XlFileFormat.xlAddIn, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                ExlWb.Close();
                ExlApp.Quit();
            }
            catch (Exception e)
            {
                LogToFile(LogFilePath, "Error", e.Message);
            }
        }
        public void RemoveBlankRows(String FilePath,String ExcelSheetName,String ColumnNameToApplyFilter, String LogFilePath)
        {
            try
            {
                LogToFile(LogFilePath, "Audit", "Opened excel file to delete blank rows");
                ExlApp = new Excel.Application();
                ExlApp.DisplayAlerts = false;
                ExlApp.Visible = true;
                ExlWb = ExlApp.Workbooks.Open(FilePath);
                ExlWs = ExlWb.Worksheets[ExcelSheetName];
                int ColumnCount = ExlWs.UsedRange.Columns.Count;
                int ColumnNumber = 1;
                for (int a = 1; a <= ColumnCount; a++)
                {
                    if (String.Compare(ExlWs.Cells[1, a].Value.ToString().ToLower(), ColumnNameToApplyFilter.ToLower()) == 0)
                    {
                        ColumnNumber = a;
                        break;
                    }
                }
                LogToFile(LogFilePath, "Audit", "Selected column number "+ColumnNumber + " to apply filter and delte");
                List<int> RN = new List<int>();
                ExlWs.UsedRange.AutoFilter(ColumnNumber, Criteria1: "=");
                Excel.Range visibleCells = ExlWs.UsedRange.SpecialCells(Excel.XlCellType.xlCellTypeVisible, Type.Missing);
                bool skip = true;
                LogToFile(LogFilePath, "Audit", "Recording row numbers to delete");
                foreach (Excel.Range area in visibleCells.Areas)
                {
                    foreach (Excel.Range row in area.Rows)
                    {
                        if (skip == false)
                        {
                            RN.Add(row.Row);
                        }
                        skip = false;
                    }
                }
                LogToFile(LogFilePath, "Audit", "Started deleting row numbers");
                ExlWs.AutoFilter.ShowAllData();
                for (int j = RN.Count() - 1; j >= 0; j--)
                {
                    ExlWs.Cells[RN.ElementAt(j), 1].EntireRow.Delete();
                }
                ExlWb.SaveAs(FilePath, Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                ExlWb.Close();
                ExlApp.Quit();
            }
            catch(Exception e)
            {
                LogToFile(LogFilePath, "Error", e.Message);
            }
        }
        public void CalculateK3Recon(String SourcePath, String DestinationPath, String SheetName, String ColumnHeaderNameToBeFiltered)
        {
            try
            {
                ExlApp = new Excel.Application();
                ExlApp.DisplayAlerts = false;
                ExlWb = ExlApp.Workbooks.Open(SourcePath);
                ExlWs = ExlWb.Worksheets[SheetName];
                int RowCount = ExlWs.UsedRange.Rows.Count + 1;
                int ColumnCount = ExlWs.UsedRange.Columns.Count;
                //LogToFile(LogFilePath, "Audit", "Remove empty columns in excel sheet while formatting");
                int ColumnNumber = 1;
                ColumnCount = ExlWs.UsedRange.Columns.Count;
                for (int a = 1; a <= ColumnCount; a++)
                {
                    if (String.Compare(ExlWs.Cells[1, a].Value.ToString().ToLower(), ColumnHeaderNameToBeFiltered.ToLower()) == 0)
                    {
                        ColumnNumber = a;
                        break;
                    }
                }
                //LogToFile(LogFilePath, "Audit", "Filtering and removing blanks based on column number " + ColumnNumber);
                List<int> RN = new List<int>();
                ExlWs.UsedRange.AutoFilter(ColumnNumber, Criteria1: "=,");
                Excel.Range visibleCells = ExlWs.UsedRange.SpecialCells(Excel.XlCellType.xlCellTypeVisible, Type.Missing);
                bool skip = true;
                foreach (Excel.Range area in visibleCells.Areas)
                {
                    foreach (Excel.Range row in area.Rows)
                    {
                        if (skip == false)
                        {
                            RN.Add(row.Row);
                        }
                        skip = false;
                    }
                }
                //LogToFile(LogFilePath, "Audit", "Started Deleting rows based on column number " + ColumnNumber);
                ExlWs.AutoFilter.ShowAllData();
                for (int j = RN.Count() - 1; j >= 0; j--)
                {
                    String s=ExlWs.Cells[RN.ElementAt(j), 25].Value.ToString();
                    s.Replace("Available in Travel Agesnt Data in row(s) ","");
                    String MyFormula = String.Empty;
                    String[] MyArr = s.Split(',');
                    foreach(String Value in MyArr)
                    {
                        if (MyFormula == String.Empty)
                        {
                            MyFormula = "'K3'!M" + Convert.ToInt32(Value.Trim());
                        }
                        else
                        {
                            MyFormula = MyFormula +","+"'K3'!M" + Convert.ToInt32(Value.Trim());
                        }
                    }
                    ExlWs.Cells[RN.ElementAt(j), ColumnNumber].Formula = "SUM("+MyFormula+")";
                }
                ExlWb.SaveAs(DestinationPath, Excel.XlFileFormat.xlAddIn, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Excel.XlSaveConflictResolution.xlLocalSessionChanges,
            Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                ExlWb.Close();
                ExlApp.Quit();
                //LogToFile(LogFilePath, "Audit", "Saving all the changes to excel file and closing the same");
            }
            catch (Exception e)
            {
                //LogToFile(LogFilePath, "Error", e.Message);
            }
        }
    }
}
